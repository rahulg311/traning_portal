import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Play, Clock, CheckCircle, User, ArrowLeft } from "lucide-react";
import data from "../db";
import axios from "axios";

import { toast, ToastContainer } from "react-toastify";
const Dashboard = () => {
  let baseUrl = "https://api1.parinaam.in/api/Training/";

  const location = useLocation();
  const {languagesId, UidData} = location?.state;
  const navigate = useNavigate();
  const [userData, setUserData] = useState({});
  const [AddLanguageId, setAddLanguageId] = useState([]);

  console.log("AddLanguageId",languagesId, UidData)

  useEffect(() => {
  GetUserDetailes();
  }, []);

  useEffect(()=>{
  ViewTranslationList()
  },[])


  //  get api call language details lable
  const ViewTranslationList = async()=>{
    let LanguageIdData= {LanguageId:languagesId}
    let response = await axios.post(baseUrl+"ViewTranslation",LanguageIdData)
    // console.log("response?.data?.ViewTranslation",response?.data?.ViewTranslation)
    try {
      if(Object.keys(response?.data?.ViewTranslation).length != 0){
        setAddLanguageId(response?.data?.ViewTranslation)
      }else{
        console.log("api error in LanguageId list")
      }
    } catch (error) {
      console.log(error)
      
    }

  }
  
  const GetUserDetailes = async () => {
    // Input validation
    if (!languagesId || !UidData) {
      console.log("Error: Missing required fields (languageid or UID).");
      return;
    }
  
    const data = {
      languageid: languagesId,
      UID: UidData,
    };
  
    try {
      const res = await axios.post(baseUrl + "GetTrainingUIDDetails", data);
  
      // Check for server-side validation errors
      if (res?.data?.GetTrainingUIDDetails[0]?.Message === "Invalid UID format") {
        console.log("Error: Invalid UID format.");
        return;
      }
  
      const parsedData = JSON.parse(res?.data?.GetTrainingUIDDetails[0]?.Data);
  
      // Validate parsedData
      if (!parsedData || Object.keys(parsedData).length === 0) {
        console.log("Error: Received empty data.");
      } else {
        setUserData(parsedData); // Assuming setUserData is defined elsewhere in your component
      }
    } catch (error) {
      // Catch network or unexpected errors
      console.error("Error while fetching user details:", error.message);
    }
  };
  
  const startServerTime = async (userData, items,AddLanguageId) => {
    const data = {
      empcode: userData.empid,
      trainingid: items,
      projectcode: userData.project,
    };
    try {
      let response = await axios.post(baseUrl + "TrainingStartTime", data);
      if (response.data.TrainingStartTime[0].Message == "Success") {
       
        toast.success("Training Start");
        setTimeout(() => {
          navigate("/Videos", {
            state: {
              userData,
              trainingId: items,
              AddLanguageId
            },
          });
        }, 1500);
      } else {
        console.error("not start tarining video error:", response);
      }
    } catch (error) {
      console.log("error", error);
    }
  };

  return (
    <div className="d-flex flex-column min-vh-100">
      <ToastContainer />
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary position-fixed w-100 z-1">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">
           {AddLanguageId?.TrainingDashboard}
          </a>
          <div className="dropdown">
            <button
              className="btn btn-outline-light dropdown-toggle d-flex align-items-center"
              type="button"
              id="userProfileDropdown"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              <User className="me-2" size={18} />
              <span>{AddLanguageId?.UserProfile}</span>
            </button>
            <ul
              className="dropdown-menu dropdown-menu-end shadow-sm"
              aria-labelledby="userProfileDropdown"
            >
              {/* <li>
                <h6 className="dropdown-header">User Information</h6>
              </li> */}
              <li>
                <a className="dropdown-item" >
                  <strong>{AddLanguageId?.Name}:</strong> {userData.empname}
                </a>
              </li>
              <li>
                <a className="dropdown-item" >
                  <strong>{AddLanguageId?.ProjectCode}:</strong> {userData.project}
                </a>
              </li>
              <li>
                <hr className="dropdown-divider" />
              </li>
              {/* <li>
                <a className="dropdown-item text-danger" onClick={logouts}>Log out</a>
              </li> */}
            </ul>
          </div>
        </div>
      </nav>

      <div className="container-fluid flex-grow-1 bg-light d-flex align-items-center justify-content-center py-5 mt-4">
        <div className="row justify-content-center w-100">
        <div className="d-flex align-items-center" onClick={()=>navigate("/")}>
        <ArrowLeft className="me-2" size={18} />
        
        <h6 className="mt-2" >{AddLanguageId?.back}</h6>
        </div>
          <div className="col-md-8 col-lg-6">
            <div className="card">
              <div className="card-header bg-primary text-white text-center py-4">
                <h4 className="mb-0">{AddLanguageId?.TrainingVideoDashboard}</h4>
              </div>
              <div className="card-body ">
        
                <h3 className="fs-5 fw-bold mb-4">{AddLanguageId?.VideoInformation}</h3>
                <div className="row">
                  {userData?.trainings?.map((item, index) => (
                    <div key={index} className="col-12 col-md-12 mb-4">
                      <div className="card h-100 shadow-sm">
                        <div className="card-body">
                          <div className="row mt-2">
                            <div className="col-12 col-md-12  mb-3">
                              <div className="d-flex align-items-center">
                                <CheckCircle
                                  className="text-success me-2"
                                  size={18}
                                />
                                <div className="d-flex ">
                                  <div className="fw-semibold me-2">
                                    {AddLanguageId?.TrainingName} :
                                  </div>
                                  <div>{item.trainingname}</div>
                                </div>
                              </div>
                            </div>
                            <div className="col-12 col-md-6  mb-3">
                              <div className="d-flex align-items-center">
                                <CheckCircle
                                  className="text-success me-2"
                                  size={18}
                                />
                                <div className="d-flex ">
                                  <div className="fw-semibold me-2">
                                    {AddLanguageId?.CompletedTraining}:
                                  </div>
                                  <span className="badge bg-success">
                                    {item.completionstatus}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="col-12 col-md-6 mb-3">
                              <div className="d-flex align-items-center">
                                <Clock
                                  className="text-warning me-2"
                                  size={18}
                                />
                                <div className="d-flex ">
                                  <div className="fw-semibold me-2">
                                {AddLanguageId.VideoDuration} :
                                  </div>
                                  <div>{item.videoduration}</div>
                                </div>
                              </div>
                            </div>
                            <div className="col-12 col-md-6  mb-3">
                              <div className="d-flex align-items-center">
                                <Clock
                                  className="text-primary me-2"
                                  size={18}
                                />
                                <div className="d-flex ">
                                  <div className="fw-semibold me-2">
                                    {AddLanguageId?.VideoSeenDuration}
                                  </div>
                                  <div>{ item?.videoseenduration ||"0"} </div>
                                </div>
                              </div>
                            </div>

                            <div className="col-12 col-md-6 mb-3">
                              <div className="d-flex align-items-center">
                                <Clock
                                  className="text-secondary me-2"
                                  size={18}
                                />
                                <div className="d-flex ">
                                  <div className="fw-semibold me-2">
                                 {AddLanguageId?.StartDate}:
                                  </div>
                                  <div>{item.trainingstartdate}</div>
                                </div>
                              </div>
                            </div>
                            <div className="col-12 col-md-6 mb-3">
                              <div className="d-flex align-items-center">
                                <Clock className="text-info me-2" size={18} />
                                <div className="d-flex ">
                                  <div className="fw-semibold me-2">
                                   {AddLanguageId?.ExpiryDate}:
                                  </div>
                                  <div>{item.trainingexpirydate}</div>
                                </div>
                              </div>
                            </div>
                          
                        
                        {
                          item.completionstatus =="Yes" ?
                    
                            <div className="d-grid mt-4">
                            <button
                              
                                className="btn btn-success video-disabled btn-lg d-flex align-items-center justify-content-center"
                              >
                                <CheckCircle
                                  className="text-white me-2"
                                  // size={18}
                                />
                                <span> 
                               {AddLanguageId?.Completed} !</span>
                              </button> 
                              </div> :      <div className="d-grid mt-4">
                              <button
                                onClick={() => {
                                  startServerTime(userData, item?.trainingid,AddLanguageId);
                                }}
                                className="btn btn-primary btn-lg d-flex align-items-center justify-content-center"
                              >
                                <Play className="me-2" />
                                <span>{AddLanguageId?.StartTrainingVideo}</span>
                              </button>
                            </div> 
                        }
                        
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
